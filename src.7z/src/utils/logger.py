def log_to_listbox(listbox, message: str):
    listbox.insert('end', message)
